window.__require = function e(t, s, o) {
function n(a, r) {
if (!s[a]) {
if (!t[a]) {
var c = a.split("/");
c = c[c.length - 1];
if (!t[c]) {
var h = "function" == typeof __require && __require;
if (!r && h) return h(c, !0);
if (i) return i(c, !0);
throw new Error("Cannot find module '" + a + "'");
}
}
var l = s[a] = {
exports: {}
};
t[a][0].call(l.exports, function(e) {
return n(t[a][1][e] || e);
}, l, l.exports, e, t, s, o);
}
return s[a].exports;
}
for (var i = "function" == typeof __require && __require, a = 0; a < o.length; a++) n(o[a]);
return n;
}({
CaseExperience: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "f5b13cJHMFKhLlf0K+qgxKk", "CaseExperience");
cc.Class({
extends: cc.Component,
properties: {
web: cc.WebView,
back: cc.Button,
btnOpenWithBrowser: cc.Button
},
onLoad: function() {
this.back.node.on("click", this.onBack, this);
this.btnOpenWithBrowser.node.on("click", this.openWithBrowser, this);
},
onBack: function() {
cc.director.loadScene("index");
},
openWithBrowser: function() {
console.log("open ", this.web.url);
window.open(this.web.url);
}
});
cc._RF.pop();
}, {} ],
ExampleExplain: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "a48d5Ac3k9Oh71kQ5LAbiN1", "ExampleExplain");
cc.Class({
extends: cc.Component,
properties: {
web: cc.WebView,
back: cc.Button
},
onLoad: function() {
this.back.node.on("click", this.onBack, this);
this.web.node.on("loaded", this.callback, this);
},
onBack: function() {
cc.director.loadScene("index");
},
callback: function(e) {
console.log("1111111111111");
},
onDestroy: function() {}
});
cc._RF.pop();
}, {} ],
ExamplesData: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "f46c6jxDk1Mj7MfJ9xB1aRp", "ExamplesData");
var o = {
gameID: 214415,
channel: "Matchvs",
platform: "alpha",
gameVersion: 1,
appKey: "479d25236a274961bd2fea127c277027#C",
userName: "",
mxaNumer: 3,
userID: "",
token: "",
host: "",
isPAAS: !1,
reset: function() {
o.gameID = "";
o.appKey = "";
o.userID = "";
o.token = "";
}
};
t.exports = o;
cc._RF.pop();
}, {} ],
Index: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "0c67eeDeuNCrYURpguviuko", "Index");
cc.Class({
extends: cc.Component,
properties: {
caseExperience: cc.Button,
networkFlow: cc.Button,
exampleExplain: cc.Button
},
onLoad: function() {
this.caseExperience.node.on("click", this.startScene, this);
this.networkFlow.node.on("click", this.startScene, this);
this.exampleExplain.node.on("click", this.startScene, this);
},
startScene: function(e) {
switch (e.node.name) {
case "caseExperience":
cc.director.loadScene("caseExperience");
break;

case "networkFlow":
cc.director.loadScene("pass");
break;

case "exampleExplain":
cc.director.loadScene("exampleExplain");
}
}
});
cc._RF.pop();
}, {} ],
Item: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "c9d09/xtr5PmqItVoRLaB+G", "Item");
cc.Class({
extends: cc.Component,
properties: {
logLable: cc.Label
},
onLoad: function() {},
updateItem: function(e) {
this.logLable.string = e;
}
});
cc._RF.pop();
}, {} ],
MatchvsEngine: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "6d436wfdopDBZUJHITrWOZ9", "MatchvsEngine");
var o = e("Matchvs"), n = e("ExamplesData");
function i() {}
i.prototype.init = function(e, t, s, n) {
var i = o.engine.init(o.response, e, t, s, n, 1);
console.log("初始化result" + i);
return i;
};
i.prototype.premiseInit = function(e, t, s) {
var n = o.engine.premiseInit(o.response, e, t, s);
console.log("独立部署初始化result" + n);
return n;
};
i.prototype.registerUser = function() {
var e = o.engine.registerUser();
console.log("注册result" + e);
return e;
};
i.prototype.login = function(e, t) {
var s = o.engine.login(e, t, "matchvs");
console.log("登录result" + s);
return s;
};
i.prototype.joinRandomRoom = function(e) {
var t = o.engine.joinRandomRoom(e, n.userName + "进入了房间");
console.log("随机匹配result" + t);
return t;
};
i.prototype.joinOver = function() {
var e = o.engine.joinOver("关闭房间");
console.log("joinOver result" + e);
return e;
};
i.prototype.sendEvent = function(e) {
return o.engine.sendEvent(e).result;
};
i.prototype.leaveRoom = function() {
return o.engine.leaveRoom("离开房间");
};
i.prototype.logout = function() {
return o.engine.logout("注销");
};
i.prototype.unInit = function() {
return o.engine.uninit();
};
t.exports = i;
cc._RF.pop();
}, {
ExamplesData: "ExamplesData",
Matchvs: "Matchvs"
} ],
MatchvsResponse: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "a6ccbQYn5hP452vQBg+xwxB", "MatchvsResponse");
var o = e("Matchvs"), n = e("MatvhsvsMessage");
function i() {}
i.prototype.init = function(e) {
this.context = e;
};
i.prototype.bind = function() {
o.response.initResponse = this.initResponse.bind(this);
o.response.registerUserResponse = this.registerUserResponse.bind(this);
o.response.loginResponse = this.loginResponse.bind(this);
o.response.errorResponse = this.errorResponse.bind(this);
o.response.joinRoomResponse = this.joinRoomResponse.bind(this);
o.response.joinRoomNotify = this.joinRoomNotify.bind(this);
o.response.leaveRoomResponse = this.leaveRoomResponse.bind(this);
o.response.leaveRoomNotify = this.leaveRoomNotify.bind(this);
o.response.joinOverResponse = this.joinOverResponse.bind(this);
o.response.joinOverNotify = this.joinOverNotify.bind(this);
o.response.sendEventResponse = this.sendEventResponse.bind(this);
o.response.sendEventNotify = this.sendEventNotify.bind(this);
};
i.prototype.initResponse = function(e) {
this.context.node.emit(n.MATCHVS_INIT, e);
};
i.prototype.registerUserResponse = function(e) {
console.log(JSON.stringify(e));
this.context.node.emit(n.MATCHVS_REGISTER_USER, e);
};
i.prototype.loginResponse = function(e) {
this.context.node.emit(n.MATCHVS_LOGIN, e);
};
i.prototype.joinRoomResponse = function(e, t, s) {
this.context.node.emit(n.MATCHVS_JOIN_ROOM_RSP, e, t, s);
};
i.prototype.joinRoomNotify = function(e) {
console.log(e.userID + "加入了房间");
this.context.node.emit(n.MATCHVS_JOIN_ROOM_NOTIFY, e);
};
i.prototype.joinOverResponse = function(e) {
this.context.node.emit(n.MATCHVS_JOIN_OVER_RSP, e);
};
i.prototype.joinOverNotify = function(e) {
this.context.node.emit(n.MATCHVS_JOIN_OVER_NOTIFY, e);
};
i.prototype.sendEventResponse = function(e) {
this.context.node.emit(n.MATCHVS_SEND_EVENT_RSP, e);
};
i.prototype.sendEventNotify = function(e) {
this.context.node.emit(n.MATCHVS_SEND_EVENT_NOTIFY, e);
};
i.prototype.leaveRoomResponse = function(e) {
this.context.node.emit(n.MATCHVS_LEAVE_ROOM, e);
};
i.prototype.leaveRoomNotify = function(e) {
this.context.node.emit(n.MATCHVS_LEAVE_ROOM_NOTIFY, e);
};
i.prototype.errorResponse = function(e, t) {
console.log("发生错误了！！！");
this.context.node.emit(n.MATCHVS_ERROE_MSG, e, t);
};
t.exports = i;
cc._RF.pop();
}, {
Matchvs: "Matchvs",
MatvhsvsMessage: "MatvhsvsMessage"
} ],
Matchvs: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "c17e1oK2fxOmYfTT0kZbQQ/", "Matchvs");
var o, n, i, a, r, c;
try {
o = new window.MatchvsEngine();
n = new window.MatchvsResponse();
i = window.MsMatchInfo;
a = window.MsCreateRoomInfo;
r = window.MsRoomFilterEx;
c = window.LocalStore_Clear;
console.log(void 0);
if ("undefined" != typeof BK || "undefined" != typeof FBInstant) {
MVS.SetWss && MVS.SetWss(!0);
console.log("use wss");
}
console.log("load matchvs.all.js success");
} catch (e) {
console.error("try load matchvs JS fail," + e.message);
}
t.exports = {
engine: o,
response: n,
MsMatchInfo: i,
MsCreateRoomInfo: a,
MsRoomFilterEx: r,
LocalStore_Clear: c
};
cc._RF.pop();
}, {} ],
MatvhsvsMessage: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "15934C7ar9JJ6IJybZqrqGJ", "MatvhsvsMessage");
t.exports = {
MATCHVS_INIT: "MATCHVS_INIT",
MATCHVS_REGISTER_USER: "MATCHVS_REGISTER_USER",
MATCHVS_LOGIN: "MATCHVS_LOGIN",
MATCHVS_RE_CONNECT: "MATCHVS_RE_CONNECT",
MATCHVS_ERROE_MSG: "MATCHVS_ERROE_MSG",
MATCHVS_JOIN_ROOM_RSP: "MATCHVS_JOIN_ROOM_RSP",
MATCHVS_JOIN_ROOM_NOTIFY: "MATCHVS_JOIN_ROOM_NOTIFY",
MATCHVS_LEAVE_ROOM: "MATCHVS_LEAVE_ROOM",
MATCHVS_LEAVE_ROOM_NOTIFY: "MATCHVS_LEAVE_ROOM_NOTIFY",
MATCHVS_JOIN_OVER_RSP: "MATCHVS_JOIN_OVER_RSP",
MATCHVS_JOIN_OVER_NOTIFY: "MATCHVS_JOIN_OVER_NOTIFY",
MATCHVS_JOIN_OPEN_RSP: "MATCHVS_JOIN_OPEN_RSP",
MATCHVS_JOIN_OPEN_NOTIFY: "MATCHVS_JOIN_OPEN_NOTIFY",
MATCHVS_ROOM_LIST_EX: "MATCHVS_ROOM_LIST_EX",
MATCHVS_CREATE_ROOM: "MATCHVS_CREATE_ROOM",
MATCHVS_ROOM_DETAIL: "MATCHVS_ROOM_DETAIL",
MATCHVS_KICK_PLAYER: "MATCHVS_KICK_PLAYER",
MATCHVS_KICK_PLAYER_NOTIFY: "MATCHVS_KICK_PLAYER_NOTIFY",
MATCHVS_SET_ROOM_PROPETY: "MATCHVS_SET_ROOM_PROPETY",
MATCHVS_SET_ROOM_PROPETY_NOTIFY: "MATCHVS_SET_ROOM_PROPETY_NOTIFY",
MATCHVS_SEND_EVENT_RSP: "MATCHVS_SEND_EVENT_RSP",
MATCHVS_SEND_EVENT_NOTIFY: "MATCHVS_SEND_EVENT_NOTIFY",
MATCHVS_FRAME_UPDATE: "MATCHVS_FRAME_UPDATE",
MATCHVS_WX_BINDING: "MATCHVS_WX_BINDING",
MATCHVS_NETWORK_STATE_NOTIFY: "MATCHVS_NETWORK_STATE_NOTIFY",
MATCHVS_LOGOUT: "MATCHVS_LOGOUT"
};
cc._RF.pop();
}, {} ],
NetworkFlow: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "d9a62MtAWtPi6C2uFPLL69E", "NetworkFlow");
var o = e("../1/MatchvsEngine"), n = e("../1/MatchvsResponse"), i = e("../1/MatvhsvsMessage"), a = e("../1/ExamplesData");
cc.Class({
extends: cc.Component,
properties: {
initButton: cc.Button,
registerButton: cc.Button,
loginButton: cc.Button,
joinRandomRoomButton: cc.Button,
joinOverButton: cc.Button,
sendEventButton: cc.Button,
leaveRoomButton: cc.Button,
logoutButton: cc.Button,
unInitButton: cc.Button,
clearLogButton: cc.Button,
backHomeButton: cc.Button,
textTitle: cc.Label,
btnClear: cc.Button,
btnSAAS: cc.Button,
ebGameID: cc.EditBox,
ebAppKey: cc.EditBox,
ebEndPoint: cc.EditBox,
ebUserID: cc.EditBox,
ebToken: cc.EditBox,
textToturail: cc.Node,
passGroup: cc.Node,
logListView: {
default: null,
type: cc.ScrollView
},
logList: [],
spacing: 0,
totalCount: 0,
itemTemplate: {
default: null,
type: cc.Node
}
},
onLoad: function() {
this.initMatchvsEvent(this);
this.logList = new Array();
this.content = this.logListView.content;
this.initButton.node.on("click", this.init, this);
this.registerButton.node.on("click", this.register, this);
this.loginButton.node.on("click", this.login, this);
this.joinRandomRoomButton.node.on("click", this.joinRandomRoom, this);
this.joinOverButton.node.on("click", this.joinOver, this);
this.sendEventButton.node.on("click", this.sendEvent, this);
this.leaveRoomButton.node.on("click", this.leaveRoom, this);
this.logoutButton.node.on("click", this.logout, this);
this.unInitButton.node.on("click", this.unInit, this);
this.backHomeButton.node.on("click", this.backHome, this);
this.clearLogButton.node.on("click", this.clearLog, this);
this.btnSAAS.node.on("click", function() {
a.isPAAS = !a.isPAAS;
o.prototype.logout();
o.prototype.unInit();
cc.director.loadScene("pass");
}, this);
this.btnClear.node.on("click", function() {
LocalStore_Clear();
this.labelLog("已删除UserID和Token的本地缓存");
}, this);
this.textToturail.on(cc.Node.EventType.MOUSE_UP, function() {
window.open("https://doc.matchvs.com/SelfHost/selfhostIntro");
}, this);
this.labelLog("您需要打开两个以上的浏览器模拟多人联网进行测试使用");
if (a.isPAAS) {
this.ebGameID.getComponent(cc.EditBox).string = "";
this.ebAppKey.getComponent(cc.EditBox).string = "";
this.ebUserID.getComponent(cc.EditBox).string = "";
this.ebToken.getComponent(cc.EditBox).string = "";
this.ebEndPoint.getComponent(cc.EditBox).string = "";
this.getAndCheckPAASInfo();
a.reset();
} else {
this.ebGameID.getComponent(cc.EditBox).string = a.gameID;
this.ebAppKey.getComponent(cc.EditBox).string = a.appKey;
}
this.getAndCheckGameInfo();
this.textTitle.string = a.isPAAS ? "自托管模式" : "云托管模式";
this.btnClear.node.active = !a.isPAAS;
this.passGroup.active = a.isPAAS;
console.log("isPaas:", a.isPAAS);
this.btnSAAS.getComponentInChildren(cc.Label).string = a.isPAAS ? "云托管模式" : "自托管模式";
console.log("GameData:", a);
},
premiseInit: function() {
this.getAndCheckPAASInfo() && o.prototype.premiseInit(a.host, a.gameID, a.appKey);
},
getAndCheckPAASInfo: function() {
var e = this.ebToken.getComponent(cc.EditBox).string, t = this.ebUserID.getComponent(cc.EditBox).string, s = this.ebEndPoint.getComponent(cc.EditBox).string;
if ("" === t || "" === e || "" === s) {
this.labelLog("独立部署请输入userID,token以及服务地址");
this.labelLog("有疑问请点击右上角<自托管教程>按钮");
return !1;
}
a.userID = t;
a.token = e;
a.host = s;
return !0;
},
getAndCheckGameInfo: function() {
var e = this.ebGameID.getComponent(cc.EditBox).string, t = this.ebAppKey.getComponent(cc.EditBox).string;
if ("" === e || "" === t) {
this.labelLog("gameID&&appKey不能为空,请输入");
console.log("GameData:", a);
return !1;
}
a.gameID = e;
a.appKey = t;
return !0;
},
initMatchvsEvent: function(e) {
n.prototype.bind();
n.prototype.init(e);
this.node.on(i.MATCHVS_INIT, this.initResponse, this);
this.node.on(i.MATCHVS_REGISTER_USER, this.registerUserResponse, this);
this.node.on(i.MATCHVS_LOGIN, this.loginResponse, this);
this.node.on(i.MATCHVS_JOIN_ROOM_RSP, this.joinRoomResponse, this);
this.node.on(i.MATCHVS_JOIN_ROOM_NOTIFY, this.joinRoomNotify, this);
this.node.on(i.MATCHVS_JOIN_OVER_RSP, this.joinOverResponse, this);
this.node.on(i.MATCHVS_JOIN_OVER_NOTIFY, this.joinOverNotify, this);
this.node.on(i.MATCHVS_SEND_EVENT_RSP, this.sendEventResponse, this);
this.node.on(i.MATCHVS_SEND_EVENT_NOTIFY, this.sendEventNotify, this);
this.node.on(i.MATCHVS_LEAVE_ROOM, this.leaveRoomResponse, this);
this.node.on(i.MATCHVS_LEAVE_ROOM_NOTIFY, this.leaveRoomNotify, this);
this.node.on(i.MATCHVS_LOGOUT, this.logoutResponse, this);
this.node.on(i.MATCHVS_ERROE_MSG, this.errorResponse, this);
},
removeEvent: function() {
this.node.off(i.MATCHVS_INIT, this.initResponse, this);
this.node.off(i.MATCHVS_REGISTER_USER, this.registerUserResponse, this);
this.node.off(i.MATCHVS_LOGIN, this.loginResponse, this);
this.node.off(i.MATCHVS_JOIN_ROOM_RSP, this.joinRoomResponse, this);
this.node.off(i.MATCHVS_JOIN_ROOM_NOTIFY, this.joinRoomNotify, this);
this.node.off(i.MATCHVS_JOIN_OVER_RSP, this.joinOverResponse, this);
this.node.off(i.MATCHVS_JOIN_OVER_NOTIFY, this.joinOverNotify, this);
this.node.off(i.MATCHVS_SEND_EVENT_RSP, this.sendEventResponse, this);
this.node.off(i.MATCHVS_SEND_EVENT_NOTIFY, this.sendEventNotify, this);
this.node.off(i.MATCHVS_LEAVE_ROOM, this.leaveRoomResponse, this);
this.node.off(i.MATCHVS_LEAVE_ROOM_NOTIFY, this.leaveRoomNotify, this);
this.node.off(i.MATCHVS_LOGOUT, this.logoutResponse, this);
this.node.off(i.MATCHVS_ERROE_MSG, this.errorResponse, this);
},
backHome: function() {
cc.director.loadScene("index");
},
clearLog: function() {
this.logList.length = 0;
this.content.removeAllChildren(!0);
},
init: function() {
var e;
if (a.isPAAS) {
if (!this.getAndCheckPAASInfo() || !this.getAndCheckGameInfo()) return;
e = o.prototype.premiseInit(a.host, a.gameID, a.appKey);
} else {
if (!this.getAndCheckGameInfo()) return;
e = o.prototype.init(a.channel, a.platform, a.gameID, a.appKey);
}
this.labelLog("初始化使用的gameID是:" + a.gameID, "如需更换为自己SDK，请修改ExamplesData.js文件");
this.engineCode(e, "init");
},
register: function() {
if (a.isPAAS) this.labelLog("独立部署使用第三方账号,无需注册"); else {
var e = o.prototype.registerUser();
this.engineCode(e, "registerUser");
}
},
login: function() {
if (this.getAndCheckGameInfo()) {
var e = o.prototype.login(a.userID, a.token);
this.labelLog("登录的账号userID是:", a.userID);
if (-6 == e) this.labelLog("已登录，请勿重新登录"); else if (-26 === e) {
console.log("GameData:", a);
this.labelLog("[游戏账户与渠道不匹配，请使用cocos账号登录Matchvs官网创建游戏]：(https://www.matchvs.com/cocos)");
} else this.engineCode(e, "login");
}
},
joinRandomRoom: function() {
var e = o.prototype.joinRandomRoom(a.mxaNumer);
this.engineCode(e, "joinRandomRoom");
},
joinOver: function() {
var e = o.prototype.joinOver();
this.engineCode(e, "joinOver");
},
sendEvent: function() {
var e = [ "万剑归宗", " 亢龙有悔", "庐山升龙霸 ", " 天马流行拳", " 钻石星尘", " 凤翼天翔", "庐山亢龙霸 ", "极冻冰棺", " 等离子光速拳", "星云锁链" ][Math.floor(10 * Math.random())], t = o.prototype.sendEvent("你使出一招:" + e);
this.labelLog("你准备使出一招：" + e);
this.engineCode(t, "sendEvent");
},
leaveRoom: function() {
var e = o.prototype.leaveRoom();
this.engineCode(e, "leaveRoom");
},
logout: function() {
var e = o.prototype.logout();
this.engineCode(e, "logout");
},
unInit: function() {
var e = o.prototype.unInit();
this.engineCode(e, "unInit");
},
initResponse: function(e) {
200 == e ? this.labelLog("initResponse：初始化成功，status：" + e) : this.labelLog("initResponse：初始化失败，status：" + e);
},
registerUserResponse: function(e) {
if (0 == e.status) {
this.labelLog("registerUserResponse：注册用户成功,id = " + e.id + "token = " + e.token + "name:" + e.name + "avatar:" + e.avatar);
a.userID = e.id;
a.token = e.token;
this.ebUserID.getComponent(cc.EditBox).string = a.userID;
this.ebToken.getComponent(cc.EditBox).string = a.token;
a.userName = e.name;
} else this.labelLog("registerUserResponse: 注册用户失败");
},
loginResponse: function(e) {
200 == e.status ? this.labelLog("loginResponse: 登录成功") : 402 == e.status ? this.labelLog("loginResponse: 应用校验失败，确认是否在未上线时用了release环境，并检查gameID、appkey 和 secret") : 403 == e.status ? this.labelLog("loginResponse：检测到该账号已在其他设备登录") : 404 == e.status ? this.labelLog("loginResponse：无效用户 ") : 500 == e.status && this.labelLog("loginResponse：服务器内部错误");
},
joinRoomResponse: function(e, t, s) {
if (200 == e) {
this.labelLog("joinRoomResponse: 进入房间成功：房间ID为：" + s.roomID + "房主ID：" + s.ownerId + "房间属性为：" + s.roomProperty);
for (var o = 0; o < t.length; o++) this.labelLog("joinRoomResponse：房间的玩家ID是" + t[o].userID);
0 == t.length && this.labelLog("joinRoomResponse：房间暂时无其他玩家");
} else this.labelLog("joinRoomResponse：进入房间失败");
},
joinRoomNotify: function(e) {
this.labelLog("joinRoomNotify：加入房间的玩家ID是" + e.userID);
},
joinOverResponse: function(e) {
200 == e.status ? this.labelLog("joinOverResponse: 关闭房间成功") : 400 == e.status ? this.labelLog("joinOverResponse: 客户端参数错误 ") : 403 == e.status ? this.labelLog("joinOverResponse: 该用户不在房间 ") : 404 == e.status ? this.labelLog("joinOverResponse: 用户或房间不存在") : 500 == e.status && this.labelLog("joinOverResponse: 服务器内部错误");
},
joinOverNotify: function(e) {
this.labelLog("joinOverNotify：用户" + e.srcUserID + "关闭了房间，房间ID为：" + e.roomID);
},
sendEventResponse: function(e) {
200 == e.status ? this.labelLog("sendEventResponse：发送消息成功") : this.labelLog("sendEventResponse：发送消息失败");
},
sendEventNotify: function(e) {
this.labelLog("sendEventNotify：用户" + e.srcUserID + "对你使出了一招" + e.cpProto);
},
leaveRoomResponse: function(e) {
200 == e.status ? this.labelLog("leaveRoomResponse：离开房间成功，房间ID是" + e.roomID) : 400 == e.status ? this.labelLog("leaveRoomResponse：客户端参数错误,请检查参数") : 404 == e.status ? this.labelLog("leaveRoomResponse：房间不存在") : 500 == e.status && this.labelLog("leaveRoomResponse：服务器错误");
},
leaveRoomNotify: function(e) {
this.labelLog("leaveRoomNotify：" + e.userID + "离开房间，房间ID是" + e.roomID);
},
logoutResponse: function(e) {
200 == e ? this.labelLog("logoutResponse：注销成功") : 500 == e && this.labelLog("logoutResponse：注销失败，服务器错误");
},
errorResponse: function(e, t) {
this.labelLog("errorMsg:" + t + "errorCode:" + e);
},
labelLog: function(e) {
this.logList.push(e);
this.totalCount = this.logList.length;
this.content.height = this.totalCount * (this.itemTemplate.height + this.spacing) + this.spacing;
this.content.removeAllChildren(!0);
for (var t = 0; t < this.logList.length; t++) {
var s = cc.instantiate(this.itemTemplate);
this.content.addChild(s);
s.setPosition(0, -s.height * (.5 + t) - this.spacing * (t + 1));
s.getComponent("Item").updateItem(this.logList[t]);
}
},
engineCode: function(e, t) {
switch (e) {
case 0:
this.labelLog(t + "调用成功");
break;

case -1:
this.labelLog(t + "调用失败");
break;

case -2:
this.labelLog("尚未初始化，请先初始化再进行" + t + "操作");
break;

case -3:
this.labelLog("正在初始化，请稍后进行" + t + "操作");
break;

case -4:
this.labelLog("尚未登录，请先登录再进行" + t + "操作");
break;

case -5:
this.labelLog("已经登录，请勿重复登陆");
break;

case -6:
this.labelLog("尚未加入房间，请稍后进行" + t + "操作");
break;

case -7:
this.labelLog("正在创建或者进入房间,请稍后进行" + t + "操作");
break;

case -8:
this.labelLog("已经在房间中");
break;

case -20:
this.labelLog("maxPlayer超出范围 0 < maxPlayer ≤ 20");
break;

case -21:
this.labelLog("userProfile 过长，不能超过512个字符");
break;

case -25:
this.labelLog(t + "channel 非法，请检查是否正确填写为 “Matchvs”");
break;

case -26:
this.labelLog(t + "：platform 非法，请检查是否正确填写为 “alpha” 或 “release”");
}
},
onDestroy: function() {
this.removeEvent();
}
});
cc._RF.pop();
}, {
"../1/ExamplesData": "ExamplesData",
"../1/MatchvsEngine": "MatchvsEngine",
"../1/MatchvsResponse": "MatchvsResponse",
"../1/MatvhsvsMessage": "MatvhsvsMessage"
} ],
hotUpdate: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "995922oqZFBwoTTggIkuelM", "hotUpdate");
cc.Class({
extends: cc.Component,
properties: {
byteLabel: cc.Label,
fileLabel: cc.Label,
byteProgress: cc.ProgressBar,
fileProgress: cc.ProgressBar,
label: cc.Label,
manifestUrl: cc.RawAsset
},
onLoad: function() {
var e = this;
this._storagePath = jsb.fileUtils.getWritablePath();
this._am = new jsb.AssetsManager("", this._storagePath, this.versionCompareHandle);
cc.sys.ENABLE_GC_FOR_NATIVE_OBJECTS || this._am.retain();
this._am.setVerifyCallback(function(t, s) {
var o = s.compressed, n = s.md5, i = s.path;
s.size;
if (o) {
e.label.string = "检查版本:" + i;
return !0;
}
e.label.string = "检查版本:" + i + " (" + n + ")";
return !0;
});
this.byteProgress.progress = 0;
this.fileProgress.progress = 0;
this.hotUpdate();
},
hotUpdate: function() {
if (this._am && !this._updating) {
this._updateListener = new jsb.EventListenerAssetsManager(this._am, this.updateCb.bind(this));
cc.eventManager.addListener(this._updateListener, 1);
this._am.getState() === jsb.AssetsManager.State.UNINITED && this._am.loadLocalManifest(this.manifestUrl);
this._am.update();
this._updating = !0;
}
},
checkUpdata: function() {
if (!this._updating) {
this._am.getState() === jsb.AssetsManager.State.UNINITED && this._am.loadLocalManifest(this.manifestUrl);
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._checkListener = new jsb.EventListenerAssetsManager(this._am, this.checkCb.bind(this));
cc.eventManager.addListener(this._checkListener, 1);
this._am.checkUpdate();
this._updating = !0;
} else this.label.string = "加载 manifest 失败 ...";
}
},
changeScene: function() {
cc.director.loadScene("index");
},
checkCb: function(e) {
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.label.string = "No local manifest file found, hot update skipped.";
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.label.string = "Fail to download manifest file, hot update skipped.";
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.label.string = "Already up to date with the latest remote version.";
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this.label.string = "New version found, please try to update.";
this.fileProgress.progress = 0;
this.byteProgress.progress = 0;
break;

default:
return;
}
cc.eventManager.removeListener(this._checkListener);
this._checkListener = null;
this._updating = !1;
},
updateCb: function(e) {
var t = !1, s = !1;
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.label.string = "No local manifest file found, hot update skipped.";
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
this.byteProgress.progress = e.getPercent();
this.fileProgress.progress = e.getPercentByFile();
this.fileLabel.string = e.getDownloadedFiles() + " / " + e.getTotalFiles();
this.byteLabel.string = e.getDownloadedBytes() + " / " + e.getTotalBytes();
var o = e.getMessage();
o && (this.label.string = "Updated file: " + o);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.label.string = "Fail to download manifest file, hot update skipped.";
s = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.label.string = "Already up to date with the latest remote version.";
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
this.label.string = "Update finished. " + e.getMessage();
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this.label.string = "Update failed. " + e.getMessage();
this._updating = !1;
this._canRetry = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
this.label.string = "Asset update error: " + e.getAssetId() + ", " + e.getMessage();
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
this.label.string = e.getMessage();
}
if (s) {
cc.eventManager.removeListener(this._updateListener);
this._updateListener = null;
this._updating = !1;
}
if (t) {
cc.eventManager.removeListener(this._updateListener);
this._updateListener = null;
var n = jsb.fileUtils.getSearchPaths(), i = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift(n, i);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(n));
jsb.fileUtils.setSearchPaths(n);
cc.game.restart();
}
}
});
cc._RF.pop();
}, {} ]
}, {}, [ "CaseExperience", "ExamplesData", "Matchvs", "MatchvsEngine", "MatchvsResponse", "MatvhsvsMessage", "Item", "NetworkFlow", "ExampleExplain", "Index", "hotUpdate" ]);