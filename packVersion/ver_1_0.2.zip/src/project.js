window.__require = function e(t, o, n) {
function s(c, r) {
if (!o[c]) {
if (!t[c]) {
var a = c.split("/");
a = a[a.length - 1];
if (!t[a]) {
var h = "function" == typeof __require && __require;
if (!r && h) return h(a, !0);
if (i) return i(a, !0);
throw new Error("Cannot find module '" + c + "'");
}
}
var l = o[c] = {
exports: {}
};
t[c][0].call(l.exports, function(e) {
return s(t[c][1][e] || e);
}, l, l.exports, e, t, o, n);
}
return o[c].exports;
}
for (var i = "function" == typeof __require && __require, c = 0; c < n.length; c++) s(n[c]);
return s;
}({
CaseExperience: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "f5b13cJHMFKhLlf0K+qgxKk", "CaseExperience");
cc.Class({
extends: cc.Component,
properties: {
web: cc.WebView,
back: cc.Button,
btnOpenWithBrowser: cc.Button
},
onLoad: function() {
this.back.node.on("click", this.onBack, this);
this.btnOpenWithBrowser.node.on("click", this.openWithBrowser, this);
},
onBack: function() {
cc.director.loadScene("index");
},
openWithBrowser: function() {
console.log("open ", this.web.url);
window.open(this.web.url);
}
});
cc._RF.pop();
}, {} ],
ExampleExplain: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "a48d5Ac3k9Oh71kQ5LAbiN1", "ExampleExplain");
cc.Class({
extends: cc.Component,
properties: {
web: cc.WebView,
back: cc.Button
},
onLoad: function() {
this.back.node.on("click", this.onBack, this);
this.web.node.on("loaded", this.callback, this);
},
onBack: function() {
cc.director.loadScene("index");
},
callback: function(e) {
console.log("1111111111111");
},
onDestroy: function() {}
});
cc._RF.pop();
}, {} ],
ExamplesData: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "f46c6jxDk1Mj7MfJ9xB1aRp", "ExamplesData");
var n = {
gameID: 214415,
channel: "Matchvs",
platform: "alpha",
gameVersion: 1,
appKey: "479d25236a274961bd2fea127c277027#C",
userName: "",
mxaNumer: 3,
userID: "",
token: "",
host: "",
isPAAS: !1,
reset: function() {
n.gameID = "";
n.appKey = "";
n.userID = "";
n.token = "";
}
};
t.exports = n;
cc._RF.pop();
}, {} ],
Index: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "0c67eeDeuNCrYURpguviuko", "Index");
cc.Class({
extends: cc.Component,
properties: {
caseExperience: cc.Button,
networkFlow: cc.Button,
exampleExplain: cc.Button
},
onLoad: function() {
this.caseExperience.node.on("click", this.startScene, this);
this.networkFlow.node.on("click", this.startScene, this);
this.exampleExplain.node.on("click", this.startScene, this);
},
startScene: function(e) {
switch (e.node.name) {
case "caseExperience":
cc.director.loadScene("caseExperience");
break;

case "networkFlow":
cc.director.loadScene("pass");
break;

case "exampleExplain":
cc.director.loadScene("exampleExplain");
}
}
});
cc._RF.pop();
}, {} ],
Item: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "c9d09/xtr5PmqItVoRLaB+G", "Item");
cc.Class({
extends: cc.Component,
properties: {
logLable: cc.Label
},
onLoad: function() {},
updateItem: function(e) {
this.logLable.string = e;
}
});
cc._RF.pop();
}, {} ],
MatchvsEngine: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "6d436wfdopDBZUJHITrWOZ9", "MatchvsEngine");
var n = e("Matchvs"), s = e("ExamplesData");
function i() {}
i.prototype.init = function(e, t, o, s) {
var i = n.engine.init(n.response, e, t, o, s, 1);
console.log("初始化result" + i);
return i;
};
i.prototype.premiseInit = function(e, t, o) {
var s = n.engine.premiseInit(n.response, e, t, o);
console.log("独立部署初始化result" + s);
return s;
};
i.prototype.registerUser = function() {
var e = n.engine.registerUser();
console.log("注册result" + e);
return e;
};
i.prototype.login = function(e, t) {
var o = n.engine.login(e, t, "matchvs");
console.log("登录result" + o);
return o;
};
i.prototype.joinRandomRoom = function(e) {
var t = n.engine.joinRandomRoom(e, s.userName + "进入了房间");
console.log("随机匹配result" + t);
return t;
};
i.prototype.joinOver = function() {
var e = n.engine.joinOver("关闭房间");
console.log("joinOver result" + e);
return e;
};
i.prototype.sendEvent = function(e) {
return n.engine.sendEvent(e).result;
};
i.prototype.leaveRoom = function() {
return n.engine.leaveRoom("离开房间");
};
i.prototype.logout = function() {
return n.engine.logout("注销");
};
i.prototype.unInit = function() {
return n.engine.uninit();
};
t.exports = i;
cc._RF.pop();
}, {
ExamplesData: "ExamplesData",
Matchvs: "Matchvs"
} ],
MatchvsResponse: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "a6ccbQYn5hP452vQBg+xwxB", "MatchvsResponse");
var n = e("Matchvs"), s = e("MatvhsvsMessage");
function i() {}
i.prototype.init = function(e) {
this.context = e;
};
i.prototype.bind = function() {
n.response.initResponse = this.initResponse.bind(this);
n.response.registerUserResponse = this.registerUserResponse.bind(this);
n.response.loginResponse = this.loginResponse.bind(this);
n.response.errorResponse = this.errorResponse.bind(this);
n.response.joinRoomResponse = this.joinRoomResponse.bind(this);
n.response.joinRoomNotify = this.joinRoomNotify.bind(this);
n.response.leaveRoomResponse = this.leaveRoomResponse.bind(this);
n.response.leaveRoomNotify = this.leaveRoomNotify.bind(this);
n.response.joinOverResponse = this.joinOverResponse.bind(this);
n.response.joinOverNotify = this.joinOverNotify.bind(this);
n.response.sendEventResponse = this.sendEventResponse.bind(this);
n.response.sendEventNotify = this.sendEventNotify.bind(this);
};
i.prototype.initResponse = function(e) {
this.context.node.emit(s.MATCHVS_INIT, e);
};
i.prototype.registerUserResponse = function(e) {
console.log(JSON.stringify(e));
this.context.node.emit(s.MATCHVS_REGISTER_USER, e);
};
i.prototype.loginResponse = function(e) {
this.context.node.emit(s.MATCHVS_LOGIN, e);
};
i.prototype.joinRoomResponse = function(e, t, o) {
this.context.node.emit(s.MATCHVS_JOIN_ROOM_RSP, e, t, o);
};
i.prototype.joinRoomNotify = function(e) {
console.log(e.userID + "加入了房间");
this.context.node.emit(s.MATCHVS_JOIN_ROOM_NOTIFY, e);
};
i.prototype.joinOverResponse = function(e) {
this.context.node.emit(s.MATCHVS_JOIN_OVER_RSP, e);
};
i.prototype.joinOverNotify = function(e) {
this.context.node.emit(s.MATCHVS_JOIN_OVER_NOTIFY, e);
};
i.prototype.sendEventResponse = function(e) {
this.context.node.emit(s.MATCHVS_SEND_EVENT_RSP, e);
};
i.prototype.sendEventNotify = function(e) {
this.context.node.emit(s.MATCHVS_SEND_EVENT_NOTIFY, e);
};
i.prototype.leaveRoomResponse = function(e) {
this.context.node.emit(s.MATCHVS_LEAVE_ROOM, e);
};
i.prototype.leaveRoomNotify = function(e) {
this.context.node.emit(s.MATCHVS_LEAVE_ROOM_NOTIFY, e);
};
i.prototype.errorResponse = function(e, t) {
console.log("发生错误了！！！");
this.context.node.emit(s.MATCHVS_ERROE_MSG, e, t);
};
t.exports = i;
cc._RF.pop();
}, {
Matchvs: "Matchvs",
MatvhsvsMessage: "MatvhsvsMessage"
} ],
Matchvs: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "c17e1oK2fxOmYfTT0kZbQQ/", "Matchvs");
var n, s, i, c, r, a;
try {
n = new window.MatchvsEngine();
s = new window.MatchvsResponse();
i = window.MsMatchInfo;
c = window.MsCreateRoomInfo;
r = window.MsRoomFilterEx;
a = window.LocalStore_Clear;
console.log(void 0);
if ("undefined" != typeof BK || "undefined" != typeof FBInstant) {
MVS.SetWss && MVS.SetWss(!0);
console.log("use wss");
}
console.log("load matchvs.all.js success");
} catch (e) {
console.error("try load matchvs JS fail," + e.message);
}
t.exports = {
engine: n,
response: s,
MsMatchInfo: i,
MsCreateRoomInfo: c,
MsRoomFilterEx: r,
LocalStore_Clear: a
};
cc._RF.pop();
}, {} ],
MatvhsvsMessage: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "15934C7ar9JJ6IJybZqrqGJ", "MatvhsvsMessage");
t.exports = {
MATCHVS_INIT: "MATCHVS_INIT",
MATCHVS_REGISTER_USER: "MATCHVS_REGISTER_USER",
MATCHVS_LOGIN: "MATCHVS_LOGIN",
MATCHVS_RE_CONNECT: "MATCHVS_RE_CONNECT",
MATCHVS_ERROE_MSG: "MATCHVS_ERROE_MSG",
MATCHVS_JOIN_ROOM_RSP: "MATCHVS_JOIN_ROOM_RSP",
MATCHVS_JOIN_ROOM_NOTIFY: "MATCHVS_JOIN_ROOM_NOTIFY",
MATCHVS_LEAVE_ROOM: "MATCHVS_LEAVE_ROOM",
MATCHVS_LEAVE_ROOM_NOTIFY: "MATCHVS_LEAVE_ROOM_NOTIFY",
MATCHVS_JOIN_OVER_RSP: "MATCHVS_JOIN_OVER_RSP",
MATCHVS_JOIN_OVER_NOTIFY: "MATCHVS_JOIN_OVER_NOTIFY",
MATCHVS_JOIN_OPEN_RSP: "MATCHVS_JOIN_OPEN_RSP",
MATCHVS_JOIN_OPEN_NOTIFY: "MATCHVS_JOIN_OPEN_NOTIFY",
MATCHVS_ROOM_LIST_EX: "MATCHVS_ROOM_LIST_EX",
MATCHVS_CREATE_ROOM: "MATCHVS_CREATE_ROOM",
MATCHVS_ROOM_DETAIL: "MATCHVS_ROOM_DETAIL",
MATCHVS_KICK_PLAYER: "MATCHVS_KICK_PLAYER",
MATCHVS_KICK_PLAYER_NOTIFY: "MATCHVS_KICK_PLAYER_NOTIFY",
MATCHVS_SET_ROOM_PROPETY: "MATCHVS_SET_ROOM_PROPETY",
MATCHVS_SET_ROOM_PROPETY_NOTIFY: "MATCHVS_SET_ROOM_PROPETY_NOTIFY",
MATCHVS_SEND_EVENT_RSP: "MATCHVS_SEND_EVENT_RSP",
MATCHVS_SEND_EVENT_NOTIFY: "MATCHVS_SEND_EVENT_NOTIFY",
MATCHVS_FRAME_UPDATE: "MATCHVS_FRAME_UPDATE",
MATCHVS_WX_BINDING: "MATCHVS_WX_BINDING",
MATCHVS_NETWORK_STATE_NOTIFY: "MATCHVS_NETWORK_STATE_NOTIFY",
MATCHVS_LOGOUT: "MATCHVS_LOGOUT"
};
cc._RF.pop();
}, {} ],
NetworkFlow: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "d9a62MtAWtPi6C2uFPLL69E", "NetworkFlow");
var n = e("../1/MatchvsEngine"), s = e("../1/MatchvsResponse"), i = e("../1/MatvhsvsMessage"), c = e("../1/ExamplesData");
cc.Class({
extends: cc.Component,
properties: {
initButton: cc.Button,
registerButton: cc.Button,
loginButton: cc.Button,
joinRandomRoomButton: cc.Button,
joinOverButton: cc.Button,
sendEventButton: cc.Button,
leaveRoomButton: cc.Button,
logoutButton: cc.Button,
unInitButton: cc.Button,
clearLogButton: cc.Button,
backHomeButton: cc.Button,
textTitle: cc.Label,
btnClear: cc.Button,
btnSAAS: cc.Button,
ebGameID: cc.EditBox,
ebAppKey: cc.EditBox,
ebEndPoint: cc.EditBox,
ebUserID: cc.EditBox,
ebToken: cc.EditBox,
textToturail: cc.Node,
passGroup: cc.Node,
logListView: {
default: null,
type: cc.ScrollView
},
logList: [],
spacing: 0,
totalCount: 0,
itemTemplate: {
default: null,
type: cc.Node
}
},
onLoad: function() {
this.initMatchvsEvent(this);
this.logList = new Array();
this.content = this.logListView.content;
this.initButton.node.on("click", this.init, this);
this.registerButton.node.on("click", this.register, this);
this.loginButton.node.on("click", this.login, this);
this.joinRandomRoomButton.node.on("click", this.joinRandomRoom, this);
this.joinOverButton.node.on("click", this.joinOver, this);
this.sendEventButton.node.on("click", this.sendEvent, this);
this.leaveRoomButton.node.on("click", this.leaveRoom, this);
this.logoutButton.node.on("click", this.logout, this);
this.unInitButton.node.on("click", this.unInit, this);
this.backHomeButton.node.on("click", this.backHome, this);
this.clearLogButton.node.on("click", this.clearLog, this);
this.btnSAAS.node.on("click", function() {
c.isPAAS = !c.isPAAS;
n.prototype.logout();
n.prototype.unInit();
cc.director.loadScene("pass");
}, this);
this.btnClear.node.on("click", function() {
LocalStore_Clear();
this.labelLog("已删除UserID和Token的本地缓存");
}, this);
this.textToturail.on(cc.Node.EventType.MOUSE_UP, function() {
window.open("https://doc.matchvs.com/SelfHost/selfhostIntro");
}, this);
this.labelLog("您需要打开两个以上的浏览器模拟多人联网进行测试使用");
if (c.isPAAS) {
this.ebGameID.getComponent(cc.EditBox).string = "";
this.ebAppKey.getComponent(cc.EditBox).string = "";
this.ebUserID.getComponent(cc.EditBox).string = "";
this.ebToken.getComponent(cc.EditBox).string = "";
this.ebEndPoint.getComponent(cc.EditBox).string = "";
this.getAndCheckPAASInfo();
c.reset();
} else {
this.ebGameID.getComponent(cc.EditBox).string = c.gameID;
this.ebAppKey.getComponent(cc.EditBox).string = c.appKey;
}
this.getAndCheckGameInfo();
this.textTitle.string = c.isPAAS ? "自托管模式" : "云托管模式";
this.btnClear.node.active = !c.isPAAS;
this.passGroup.active = c.isPAAS;
console.log("isPaas:", c.isPAAS);
this.btnSAAS.getComponentInChildren(cc.Label).string = c.isPAAS ? "云托管模式" : "自托管模式";
console.log("GameData:", c);
},
premiseInit: function() {
this.getAndCheckPAASInfo() && n.prototype.premiseInit(c.host, c.gameID, c.appKey);
},
getAndCheckPAASInfo: function() {
var e = this.ebToken.getComponent(cc.EditBox).string, t = this.ebUserID.getComponent(cc.EditBox).string, o = this.ebEndPoint.getComponent(cc.EditBox).string;
if ("" === t || "" === e || "" === o) {
this.labelLog("独立部署请输入userID,token以及服务地址");
this.labelLog("有疑问请点击右上角<自托管教程>按钮");
return !1;
}
c.userID = t;
c.token = e;
c.host = o;
return !0;
},
getAndCheckGameInfo: function() {
var e = this.ebGameID.getComponent(cc.EditBox).string, t = this.ebAppKey.getComponent(cc.EditBox).string;
if ("" === e || "" === t) {
this.labelLog("gameID&&appKey不能为空,请输入");
console.log("GameData:", c);
return !1;
}
c.gameID = e;
c.appKey = t;
return !0;
},
initMatchvsEvent: function(e) {
s.prototype.bind();
s.prototype.init(e);
this.node.on(i.MATCHVS_INIT, this.initResponse, this);
this.node.on(i.MATCHVS_REGISTER_USER, this.registerUserResponse, this);
this.node.on(i.MATCHVS_LOGIN, this.loginResponse, this);
this.node.on(i.MATCHVS_JOIN_ROOM_RSP, this.joinRoomResponse, this);
this.node.on(i.MATCHVS_JOIN_ROOM_NOTIFY, this.joinRoomNotify, this);
this.node.on(i.MATCHVS_JOIN_OVER_RSP, this.joinOverResponse, this);
this.node.on(i.MATCHVS_JOIN_OVER_NOTIFY, this.joinOverNotify, this);
this.node.on(i.MATCHVS_SEND_EVENT_RSP, this.sendEventResponse, this);
this.node.on(i.MATCHVS_SEND_EVENT_NOTIFY, this.sendEventNotify, this);
this.node.on(i.MATCHVS_LEAVE_ROOM, this.leaveRoomResponse, this);
this.node.on(i.MATCHVS_LEAVE_ROOM_NOTIFY, this.leaveRoomNotify, this);
this.node.on(i.MATCHVS_LOGOUT, this.logoutResponse, this);
this.node.on(i.MATCHVS_ERROE_MSG, this.errorResponse, this);
},
removeEvent: function() {
this.node.off(i.MATCHVS_INIT, this.initResponse, this);
this.node.off(i.MATCHVS_REGISTER_USER, this.registerUserResponse, this);
this.node.off(i.MATCHVS_LOGIN, this.loginResponse, this);
this.node.off(i.MATCHVS_JOIN_ROOM_RSP, this.joinRoomResponse, this);
this.node.off(i.MATCHVS_JOIN_ROOM_NOTIFY, this.joinRoomNotify, this);
this.node.off(i.MATCHVS_JOIN_OVER_RSP, this.joinOverResponse, this);
this.node.off(i.MATCHVS_JOIN_OVER_NOTIFY, this.joinOverNotify, this);
this.node.off(i.MATCHVS_SEND_EVENT_RSP, this.sendEventResponse, this);
this.node.off(i.MATCHVS_SEND_EVENT_NOTIFY, this.sendEventNotify, this);
this.node.off(i.MATCHVS_LEAVE_ROOM, this.leaveRoomResponse, this);
this.node.off(i.MATCHVS_LEAVE_ROOM_NOTIFY, this.leaveRoomNotify, this);
this.node.off(i.MATCHVS_LOGOUT, this.logoutResponse, this);
this.node.off(i.MATCHVS_ERROE_MSG, this.errorResponse, this);
},
backHome: function() {
cc.director.loadScene("index");
},
clearLog: function() {
this.logList.length = 0;
this.content.removeAllChildren(!0);
},
init: function() {
var e;
if (c.isPAAS) {
if (!this.getAndCheckPAASInfo() || !this.getAndCheckGameInfo()) return;
e = n.prototype.premiseInit(c.host, c.gameID, c.appKey);
} else {
if (!this.getAndCheckGameInfo()) return;
e = n.prototype.init(c.channel, c.platform, c.gameID, c.appKey);
}
this.labelLog("初始化使用的gameID是:" + c.gameID, "如需更换为自己SDK，请修改ExamplesData.js文件");
this.engineCode(e, "init");
},
register: function() {
if (c.isPAAS) this.labelLog("独立部署使用第三方账号,无需注册"); else {
var e = n.prototype.registerUser();
this.engineCode(e, "registerUser");
}
},
login: function() {
if (this.getAndCheckGameInfo()) {
var e = n.prototype.login(c.userID, c.token);
this.labelLog("登录的账号userID是:", c.userID);
if (-6 == e) this.labelLog("已登录，请勿重新登录"); else if (-26 === e) {
console.log("GameData:", c);
this.labelLog("[游戏账户与渠道不匹配，请使用cocos账号登录Matchvs官网创建游戏]：(https://www.matchvs.com/cocos)");
} else this.engineCode(e, "login");
}
},
joinRandomRoom: function() {
var e = n.prototype.joinRandomRoom(c.mxaNumer);
this.engineCode(e, "joinRandomRoom");
},
joinOver: function() {
var e = n.prototype.joinOver();
this.engineCode(e, "joinOver");
},
sendEvent: function() {
var e = [ "万剑归宗", " 亢龙有悔", "庐山升龙霸 ", " 天马流行拳", " 钻石星尘", " 凤翼天翔", "庐山亢龙霸 ", "极冻冰棺", " 等离子光速拳", "星云锁链" ][Math.floor(10 * Math.random())], t = n.prototype.sendEvent("你使出一招:" + e);
this.labelLog("你准备使出一招：" + e);
this.engineCode(t, "sendEvent");
},
leaveRoom: function() {
var e = n.prototype.leaveRoom();
this.engineCode(e, "leaveRoom");
},
logout: function() {
var e = n.prototype.logout();
this.engineCode(e, "logout");
},
unInit: function() {
var e = n.prototype.unInit();
this.engineCode(e, "unInit");
},
initResponse: function(e) {
200 == e ? this.labelLog("initResponse：初始化成功，status：" + e) : this.labelLog("initResponse：初始化失败，status：" + e);
},
registerUserResponse: function(e) {
if (0 == e.status) {
this.labelLog("registerUserResponse：注册用户成功,id = " + e.id + "token = " + e.token + "name:" + e.name + "avatar:" + e.avatar);
c.userID = e.id;
c.token = e.token;
this.ebUserID.getComponent(cc.EditBox).string = c.userID;
this.ebToken.getComponent(cc.EditBox).string = c.token;
c.userName = e.name;
} else this.labelLog("registerUserResponse: 注册用户失败");
},
loginResponse: function(e) {
200 == e.status ? this.labelLog("loginResponse: 登录成功") : 402 == e.status ? this.labelLog("loginResponse: 应用校验失败，确认是否在未上线时用了release环境，并检查gameID、appkey 和 secret") : 403 == e.status ? this.labelLog("loginResponse：检测到该账号已在其他设备登录") : 404 == e.status ? this.labelLog("loginResponse：无效用户 ") : 500 == e.status && this.labelLog("loginResponse：服务器内部错误");
},
joinRoomResponse: function(e, t, o) {
if (200 == e) {
this.labelLog("joinRoomResponse: 进入房间成功：房间ID为：" + o.roomID + "房主ID：" + o.ownerId + "房间属性为：" + o.roomProperty);
for (var n = 0; n < t.length; n++) this.labelLog("joinRoomResponse：房间的玩家ID是" + t[n].userID);
0 == t.length && this.labelLog("joinRoomResponse：房间暂时无其他玩家");
} else this.labelLog("joinRoomResponse：进入房间失败");
},
joinRoomNotify: function(e) {
this.labelLog("joinRoomNotify：加入房间的玩家ID是" + e.userID);
},
joinOverResponse: function(e) {
200 == e.status ? this.labelLog("joinOverResponse: 关闭房间成功") : 400 == e.status ? this.labelLog("joinOverResponse: 客户端参数错误 ") : 403 == e.status ? this.labelLog("joinOverResponse: 该用户不在房间 ") : 404 == e.status ? this.labelLog("joinOverResponse: 用户或房间不存在") : 500 == e.status && this.labelLog("joinOverResponse: 服务器内部错误");
},
joinOverNotify: function(e) {
this.labelLog("joinOverNotify：用户" + e.srcUserID + "关闭了房间，房间ID为：" + e.roomID);
},
sendEventResponse: function(e) {
200 == e.status ? this.labelLog("sendEventResponse：发送消息成功") : this.labelLog("sendEventResponse：发送消息失败");
},
sendEventNotify: function(e) {
this.labelLog("sendEventNotify：用户" + e.srcUserID + "对你使出了一招" + e.cpProto);
},
leaveRoomResponse: function(e) {
200 == e.status ? this.labelLog("leaveRoomResponse：离开房间成功，房间ID是" + e.roomID) : 400 == e.status ? this.labelLog("leaveRoomResponse：客户端参数错误,请检查参数") : 404 == e.status ? this.labelLog("leaveRoomResponse：房间不存在") : 500 == e.status && this.labelLog("leaveRoomResponse：服务器错误");
},
leaveRoomNotify: function(e) {
this.labelLog("leaveRoomNotify：" + e.userID + "离开房间，房间ID是" + e.roomID);
},
logoutResponse: function(e) {
200 == e ? this.labelLog("logoutResponse：注销成功") : 500 == e && this.labelLog("logoutResponse：注销失败，服务器错误");
},
errorResponse: function(e, t) {
this.labelLog("errorMsg:" + t + "errorCode:" + e);
},
labelLog: function(e) {
this.logList.push(e);
this.totalCount = this.logList.length;
this.content.height = this.totalCount * (this.itemTemplate.height + this.spacing) + this.spacing;
this.content.removeAllChildren(!0);
for (var t = 0; t < this.logList.length; t++) {
var o = cc.instantiate(this.itemTemplate);
this.content.addChild(o);
o.setPosition(0, -o.height * (.5 + t) - this.spacing * (t + 1));
o.getComponent("Item").updateItem(this.logList[t]);
}
},
engineCode: function(e, t) {
switch (e) {
case 0:
this.labelLog(t + "调用成功");
break;

case -1:
this.labelLog(t + "调用失败");
break;

case -2:
this.labelLog("尚未初始化，请先初始化再进行" + t + "操作");
break;

case -3:
this.labelLog("正在初始化，请稍后进行" + t + "操作");
break;

case -4:
this.labelLog("尚未登录，请先登录再进行" + t + "操作");
break;

case -5:
this.labelLog("已经登录，请勿重复登陆");
break;

case -6:
this.labelLog("尚未加入房间，请稍后进行" + t + "操作");
break;

case -7:
this.labelLog("正在创建或者进入房间,请稍后进行" + t + "操作");
break;

case -8:
this.labelLog("已经在房间中");
break;

case -20:
this.labelLog("maxPlayer超出范围 0 < maxPlayer ≤ 20");
break;

case -21:
this.labelLog("userProfile 过长，不能超过512个字符");
break;

case -25:
this.labelLog(t + "channel 非法，请检查是否正确填写为 “Matchvs”");
break;

case -26:
this.labelLog(t + "：platform 非法，请检查是否正确填写为 “alpha” 或 “release”");
}
},
onDestroy: function() {
this.removeEvent();
}
});
cc._RF.pop();
}, {
"../1/ExamplesData": "ExamplesData",
"../1/MatchvsEngine": "MatchvsEngine",
"../1/MatchvsResponse": "MatchvsResponse",
"../1/MatvhsvsMessage": "MatvhsvsMessage"
} ]
}, {}, [ "CaseExperience", "ExamplesData", "Matchvs", "MatchvsEngine", "MatchvsResponse", "MatvhsvsMessage", "Item", "NetworkFlow", "ExampleExplain", "Index" ]);